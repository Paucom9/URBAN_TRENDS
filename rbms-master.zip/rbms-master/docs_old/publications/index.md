---
layout: default
title: Publications
---

#### Publications

**Schmucki, R.**, Pe’er, G., Roy, D. B., Stefanescu, C., Van Swaay, C. A. M., Oliver, T. H.,Kuussaari, M., Van Strien, A.J., Ries, L., Settele, J., Musche, M., Carnicer, J., Schweiger, O., Brereton, T.M., Harpke, A., Heliölä, J., Kühn, E.,  Julliard, R. (2016). *A regionally informed abundance index for supporting integrative analyses across butterfly monitoring schemes.* Journal of Applied Ecology, 53(2), 501–510. [doi:10.1111/1365-2664.12561](https://doi.org/10.1111/1365-2664.12561)
