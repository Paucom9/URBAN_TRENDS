---
layout: post
title: "site launched"
date: "2018-06-01"
categories: test
published: true
---

Well... not much to say yet, but more to come...

update this!

{% highlight r linenos %}
a <- c(1,3)
x <- 3*a
plot(a,x,main="scatterplot")
{% endhighlight %}
